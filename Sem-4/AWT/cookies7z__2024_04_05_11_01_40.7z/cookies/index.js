const express = require('express');
const cookieParser = require('cookie-parser');

const app = express();
const port = 8080
app.use(cookieParser());

app.get('/set-cookie', (req, res) => {
    res.cookie('username', 'john_doe', { maxAge: 900000, httpOnly: true });
    res.send('Cookie has been set');
  });

  app.get('/get-cookie', (req, res) => {
    const username = req.cookies.username;
    res.send(`Username from cookie: ${username}`);
  });

  app.get('/clear-cookie', (req, res) => {
    res.clearCookie('username');
    res.send('Cookie has been cleared');
  });

  app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });
  
