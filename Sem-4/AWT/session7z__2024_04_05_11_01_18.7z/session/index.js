const express = require('express');
const session = require('express-session');

const app = express();
const port = 8080;

// Configure session middleware
app.use(session({
  secret: 'mysecretkey', // Change this to a strong secret key
  resave: false,
  saveUninitialized: true
}));

// Route to set session data
app.get('/set-session', (req, res) => {
  req.session.username = 'john_doe'; // Set a session variable
  res.send('Session data set!');
});

// Route to retrieve session data
app.get('/get-session', (req, res) => {
  const username = req.session.username || 'Guest'; // Get the session variable or default to 'Guest'
  res.send(`Hello, ${username}!`);
});

// Route to clear session data
app.get('/clear-session', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.error('Error destroying session:', err);
    } else {
      res.send('Session cleared!');
    }
  });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
