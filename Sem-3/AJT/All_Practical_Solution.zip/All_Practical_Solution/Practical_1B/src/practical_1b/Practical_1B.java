//Prepared Statement
package practical_1b;

import java.sql.*;
public class Practical_1B {
    public static void main(String[] args) throws Exception
    {
        //1.Register Driver
        Class.forName("com.mysql.cj.jdbc.Driver");
  
        //2.Establish Connection by con object
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ankit123","root","");
        System.out.println("Connection Established");
      
        System.out.println("Insert Record");
        PreparedStatement stmt1=con.prepareStatement("insert into emp values(?,?,?)");
        stmt1.setString(1,"112");
        stmt1.setString(2,"Ravi");
        stmt1.setString(3,"Chennai");
        
        int i=stmt1.executeUpdate();
        System.out.println(i+ " record inserted");       
        
        con.close();
        
        
    }
    
}
