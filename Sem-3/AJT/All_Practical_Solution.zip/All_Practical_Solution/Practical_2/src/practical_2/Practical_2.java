//Practical LIst 2 procedure sql=SELECT employee.city INTO city from employee where employee.id=id
//SELECT emp.Name, emp.City INTO name, city FROM emp WHERE emp.Enroll = id
package practical_2;
import java.sql.*;
import java.util.*;

public class Practical_2 
{
    public static void main(String[] args) throws ClassNotFoundException, SQLException 
    {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ankit123","root","");
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Employee id:");
        int id=sc.nextInt();
        CallableStatement cs=con.prepareCall("{Call getdetail(?,?)}");
        cs.setInt(1, id);
//        cs.registerOutParameter(2,java.sql.Types.VARCHAR);
        cs.execute();
        System.out.println(cs.getString(2));   
        
        con.close();
    }
}
 