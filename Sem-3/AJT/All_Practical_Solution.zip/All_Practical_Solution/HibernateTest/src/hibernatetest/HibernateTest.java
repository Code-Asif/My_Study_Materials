package HibernateTest;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateTest {
    public static void main(String[] args) {
        Configuration cf = new Configuration();
        cf.configure("hibernate.cfg.xml");

        SessionFactory f = cf.buildSessionFactory();
        Session s = f.openSession();

        Transaction tr = s.beginTransaction();
        try {
            pojo p = new pojo();
            p.setC_id(123); 
            p.setName("Rahul"); 
            
            p.setAddress("rajkot"); 
            p.setEmail("abc@gmail.com");  
            s.save(p);
            tr.commit();
            System.out.println("Data Inserted successfully");
        } catch (Exception e) {
            System.out.println(e);
            if (tr != null) {
                tr.rollback();
            }
        } finally {

            s.close();
            f.close();
        }
    }
}
