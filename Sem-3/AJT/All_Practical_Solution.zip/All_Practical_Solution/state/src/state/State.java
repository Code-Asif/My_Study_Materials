package state;

import java.sql.Connection;
import java.sql.*;
import java.util.Scanner;

class state {

    public static void main(String args[]) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/nadim", "root", "");

        PreparedStatement pst = con.prepareCall("INSERT INTO EMP VALUES(?,?,?)");
        pst.setString(1, "200");
        pst.setString(2, "RAAAJ");
        pst.setString(3, "zuaan");

        pst.executeUpdate();

        System.out.println("RECORD INSERTED");

    }
}
