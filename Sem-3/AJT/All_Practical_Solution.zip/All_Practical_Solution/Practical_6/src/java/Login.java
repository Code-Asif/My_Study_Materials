
import java.io.IOException;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Login extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String setUsername = null;
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String u = request.getParameter("username");
        String p = request.getParameter("password");

        try {
            setUsername = checkLoginDetails(u, p);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (setUsername != null) {
            HttpSession session = request.getSession();
            session.setAttribute("Username", setUsername);
            RequestDispatcher rd = request.getRequestDispatcher("Profile");
            rd.forward(request, response);
        } else {
            out.print("Sorry,Username or password error!");
            request.getRequestDispatcher("index.html").include(request, response);
        }
    }

    public String checkLoginDetails(String u, String p) throws Exception {
        String getUserName = null;
        Class.forName("com.mysql.cj.jdbc.Driver");
        String url = "jdbc:mysql://localhost:3306/ankit123";
        String user = "root";
        String password = "";
        Connection conn = DriverManager.getConnection(url, user, password);
        CallableStatement cs = conn.prepareCall("{call login(?,?,?)}");
        cs.setInt(1, Integer.parseInt(u));
        cs.setString(2, p);
        cs.registerOutParameter(3, Types.VARCHAR);
        cs.execute();
        getUserName = cs.getString(3);
        return getUserName;
    }
}
