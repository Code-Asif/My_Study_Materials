/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practical_1b.pkg1;

import java.sql.*;
import java.util.Scanner;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Stranger
 */
public class Practical_1B1 {

    public static void main(String[] args) throws SQLException {

        java.sql.Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ankit123", "root", "");
     
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("select * from emp");
        System.out.println("Records\n");
        while (rs.next()) {
            System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(3) );
        }
        
        PreparedStatement pst = conn.prepareStatement("insert into emp values(?,?,?)");

        System.out.println("\n");
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter ID: ");
        pst.setInt(1, sc.nextInt());
        System.out.print("Enter Name: ");
        pst.setString(2, sc.next());
        System.out.print("Enter City: ");
        pst.setString(3, sc.next());

        System.out.println("\n" + pst.executeUpdate() + " record inserted!\n");
        rs = stmt.executeQuery("select * from emp");
        System.out.println("Records\n");
        while (rs.next()) {
            System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(3));
        }
    }

}


