/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hibernate;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author Stranger
 */
public class Hibernate {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Configuration cf = new Configuration();
        cf.configure("hibernate.cfg.xml");
        
        SessionFactory f = cf.buildSessionFactory();
        Session s = f.openSession();
        
        
//        For Fectchinf Data from database
        
        
        
        String q = "from pojo";
//        for(pojo e: r ){
//            System.out.println(e.getId() +  "   " + e.getName());
//        }



//For Inserting data in table
//        Transaction tr = s.beginTransaction();
//        try {
//            pojo p = new pojo();
//            p.setId(1);
//            p.setName("abc");
//            s.save(p);
//            tr.commit();
//            System.out.println("Data Inserted successfully");
//        } catch (Exception e) {
        Query qr = s.createQuery(q);
        
        List<pojo>r = qr.list();
        
        for(pojo e: r ){
            System.out.println(e.getId() +  "   " + e.getName());
        }



//For Inserting data in table
//        Transaction tr = s.beginTransaction();
//        try {
//            pojo p = new pojo();
//            p.setId(1);
//            p.setName("abc");
//            s.save(p);
//            tr.commit();
//            System.out.println("Data Inserted successfully");
//        } catch (Exception e) {
//            System.out.println(e);
//            if(tr != null){
//                tr.rollback();
//            }
//        }finally{
//            
//                s.close();
//                f.close();
//        }
    }
    
}
