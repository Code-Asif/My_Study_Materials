/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

public class pojo {
    int id;
    String name;

    public pojo() {
    }

    public pojo(int id) {
        this.id = id;
    }

    public pojo(String name) {
        this.name = name;
    }

    public pojo(int id, String name) {
        this.id = id;
        this.name = name;
    }
    void show(){
        System.out.println(id  +"  "+name);
    }
}
